package com.alex.gymdefinitivo

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.alex.gymdefinitivo.DB.DB
import com.alex.gymdefinitivo.activity.LoginActivity
import com.alex.gymdefinitivo.databinding.ActivityMainBinding
import com.alex.gymdefinitivo.manager.SessionManager
import com.alex.gymdefinitivo.ui.theme.GymDefinitivoTheme

class MainActivity : ComponentActivity() {

    private var mDelayHandler: Handler? = null
    private val splash_delay: Long = 3000
    var db: DB? = null
    var session: SessionManager? = null
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = DB(this)
        session = SessionManager(this)

        insertAdminData()
        mDelayHandler = Handler(Looper.getMainLooper())
        mDelayHandler?.postDelayed(mRunnable, splash_delay)
    }

    private val mRunnable: Runnable = Runnable {
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun insertAdminData() {
        try {
            val sqlCheck = "SELECT * FROM ADMIN"
            db?.fireQuery(sqlCheck).use {
                if (it != null) {
                    if (it.count > 0) {
                        Log.d("SplashActivity", "data avaiable")

                    } else {
                        val sqlQuerry =
                            "INSERT OR REPLACE INTO ADMIN(ID,USER NAME, PASSWORD,MOBILE)VALUES('1','Admin','123456','8888888888')"
                        db?.executeQuerry(sqlQuerry)
                    }
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mDelayHandler?.removeCallbacks(mRunnable)
    }

}



