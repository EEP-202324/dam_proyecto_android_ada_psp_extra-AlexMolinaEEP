package com.alex.gymdefinitivo.global

object SqlTable {
    const val admin = "Crear tabla admin(ID INTEGER PRIMARY KEY AUTOINCREMENT,USER_NAME TEXT DEFAULT '', " + "PASSWORD TEXT DEFAULT'', MOBILE TEXT DEFAULT'' )"
}